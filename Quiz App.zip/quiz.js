const quizQue = [
    {
        question: "Q1: What does CSS stand for?",
        a: "Computer Style Sheets",
        b: "Cascading Style Sheets",
        c: "Creative Style Sheets",
        d: "Colorful Style Sheets",
        ans: "ans3"
    },

    {
        question: "Q2: Which of the following is a frontend framework?",
        a: "Laravel",
        b: "Django",
        c: "Flask",
        d: "React",
        ans: "ans4"
    },

    {
        question: "Q3: Which HTML element is used to define the title of a document?",
        a: "<meta>",
        b: "<title>",
        c: "<head>",
        d: "<div>",
        ans: "ans2",
    },

    {
        question: "Q4: Which of the following is used to make a website responsive?",
        a: "Tables",
        b: "Media Queries",
        c: "Floats",
        d: "Inline Styles",
        ans: "ans2",
    },

    {
        question: "Q5:What is the primary purpose of JavaScript in web development?",
        a: "To structure the web page",
        b: "To style the web page",
        c: "To add interactivity to the web page",
        d: "To manage databases",
        ans: "ans3",
    },

    {
        question: "Q6: Which HTML tag is used to define an unordered list?",
        a: "<ul>",
        b: "<ol>",
        c: "<li>",
        d: "<list>",
        ans: "ans1",
    },

    {
        question: "Q7: What is the purpose of the z-index property in CSS?",
        a: "To define the width of an element",
        b: "To control the visibility of an element",
        c: "To control the stack order of elements",
        d: "To define the opacity of an element",
        ans: "ans3",
    },

    {
        question: "Q8: Which of the following is NOT a valid JavaScript data type?",
        a: "String",
        b: "Number",
        c: "Booolean",
        d: "Character",
        ans: "ans4",
    },

    {
        question: "Q9: How do you add a comment in HTML?",
        a: "<!-- This is a comment -->",
        b: "// This is a comment",
        c: "/* This is a comment */",
        d: "# This is a comment",
        ans: "ans1",
    },

    {
        question: "Q10: Which HTML attribute is used to define inline styles?",
        a: "link",
        b: "style",
        c: "font",
        d: "class",
        ans: "ans2",
    },
];

const question = document.querySelector('.question');
const option1 = document.querySelector('#option1');
const option2 = document.querySelector('#option2');
const option3 = document.querySelector('#option3');
const option4 = document.querySelector('#option4');
const submit = document.querySelector('#submit');

const answers = document.querySelectorAll('.answer');

const showScore = document.querySelector('#showScore');

let questionCount = 0;
let score = 0;

const loadQuestion = () => {

    const questionList = quizQue[questionCount];

    question.innerText = questionList.question;

    option1.innerText = questionList.a;
    option2.innerText = questionList.b;
    option3.innerText = questionList.c;
    option4.innerText = questionList.d;
}

loadQuestion();

const getCheckAnswer = () => {
    let answer;

    answers.forEach((curAnsElem) => {
    if (curAnsElem.checked) {
        answer = curAnsElem.id;
    }
});

return answer;

};

const deseclectAll = () => {
    answers.forEach((curAnsElem) => curAnsElem.checked = false);
}

submit.addEventListener('click', () => {
    const checkedAnswer = getCheckAnswer();
    console.log(checkedAnswer)

    if (checkedAnswer === quizQue[questionCount].ans) {
        score++;
    };

    questionCount++;

    deseclectAll(); 
    
    if(questionCount < quizQue.length){
        loadQuestion();
    }else{
        showScore.innerHTML = `
        <h3> You Scored ${score} / ${quizQue.length} ✌️</h3>
        <button class="btn" onclick = "location.reload()">Play Again</button>
        `;

        showScore.classList.remove('scoreArea');
    }
});